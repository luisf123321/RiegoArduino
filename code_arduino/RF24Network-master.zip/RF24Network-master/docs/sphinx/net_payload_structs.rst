Network Payload Structures
~~~~~~~~~~~~~~~~~~~~~~~~~~

.. doxygenstruct:: RF24NetworkFrame
    :members:

.. doxygenstruct:: RF24NetworkHeader
    :members:
