helloworld_tx_advanced.ino
==========================

.. literalinclude:: ../../../../examples/helloworld_tx_advanced/helloworld_tx_advanced.ino
    :linenos:
