helloworld_rx.py
==========================

.. literalinclude:: ../../../../RPi/pyRF24Network/examples/helloworld_rx.py
    :language: python
    :caption: RPi/pyRF24Network/examples/helloworld_rx.py
    :linenos:
