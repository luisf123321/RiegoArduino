#ifndef RF24_UTILITY_INCLUDES_H_
#define RF24_UTILITY_INCLUDES_H_

#ifndef MRAA
    #define MRAA
#endif

#include "MRAA/RF24_arch_config.h"

#endif // RF24_UTILITY_INCLUDES_H_
